<div class="clearfix mb25 oh">
  <h4 class="cat-title">Хамтран ажилдаг байгууллагууд</h4>
  <!-- jCarousel -->
  <div class="carousel-container">
    <div class="carousel-navigation">
      <a class="carousel-prev"></a>
      <a class="carousel-next"></a>
    </div>
    <div class="carousel-item-holder gallery row" data-index="0">
      <div class="four column carousel-item">
        <a href="#"><img src="\assets\upload\carouselpost5.jpg" alt=""></a>
      </div>
      <div class="four column carousel-item">
        <a href="#"><img src="\assets\upload\carouselpost1.jpg" alt=""></a>
      </div>
      <div class="four column carousel-item">
        <a href="#"><img src="\assets\upload\carouselpost2.jpg" alt=""></a>
      </div>
      <div class="four column carousel-item">
        <a href="#"><img src="\assets\upload\carouselpost3.jpg" alt=""></a>
      </div>
      <div class="four column carousel-item">
        <a href="#"><img src="\assets\upload\carouselpost4.jpg" alt=""></a>
      </div>
    </div>
  </div>
  <!-- End jCarousel -->
</div>
