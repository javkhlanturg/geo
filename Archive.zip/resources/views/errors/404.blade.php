@extends('layouts.app')

@section('content')
<section id="content" class="eight column row pull-left">
  <div class="page-container error-404">
    <p>error <b>404</b><span>Уучлаарай, хуудас олдсонгүй</span></p>
  </div>
</section>
@endsection
