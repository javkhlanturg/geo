 <?php $sub_menus = \TCG\Voyager\Models\MenuItem::where('menu_id', 2)->get(); ?>
<header class="clearfix">
  <nav id="main-menu" class="left navigation">
    <ul class="sf-menu no-bullet inline-list m0">
        <?php $__currentLoopData = $sub_menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <li><a id="menu_<?php echo e($menu->menu_id); ?>_<?php echo e($menu->id); ?>" href="<?php echo e($menu->url); ?>" ><?php echo e($menu->title); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </ul>
  </nav>

  <div class="search-bar right clearfix">
    <form action="http://www.example.com">
      <input name="s" type="text" data-value="search" value="search">
      <input name="submit" type="submit" value="">
    </form>
  </div>
</header>
