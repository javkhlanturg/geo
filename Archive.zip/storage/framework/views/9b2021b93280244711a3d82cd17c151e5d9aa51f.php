<?php $__env->startSection('css'); ?>
<style>
  .menu_active{
    background-color: #f60d2b;
    border-bottom: 1px solid transparent;
  }
  li.menu_active a{
    color: #fff;
  }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            &nbsp;
        </div>
    </div>
<div class="container">
    <div class="row">
        <div class="col-sm-8">
            <!--Post list-->
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <div class="post-style2 wow fadeIn" data-wow-duration="1s">
                <a href="#"><img src="/storage/<?php echo e($item->image); ?>" style="max-width:250px" alt=""></a>
                <div class="post-style2-detail">
                    <h3><a href="<?php echo e($menu->url); ?>/<?php echo e($item->id); ?>" title=""><?php echo e($item->title); ?></a></h3>
                    <div class="date">
                        <ul>
                            <li><img src="\assets\images\comment-01.jpg" class="img-responsive" alt=""></li>
                            <li>By <a title="" href="#"><span>Naeem Khan</span></a> --</li>
                            <li><a title="" href="#"><?php echo e(date('Y.m.d', strtotime($item->created_at))); ?></a> --</li>
                            <li><a title="" href="#"><span>275 Comments</span></a></li>
                        </ul>
                    </div>
                    <p><?php echo e($item->excerpt); ?></p>
                    <a href="<?php echo e($menu->url); ?>/<?php echo e($item->id); ?>" class="btn btn-style">Дэлгэрэнгүй</a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

        </div>
        <?php echo $__env->make('frontend.rigthmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <!-- pagination -->

    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <?php echo e($posts->links()); ?>

            </div>
            <div class="col-sm-12">
              <?php $footer_banner = App\Banners::where('id', 4)->first(); ?>
                <div class="banner">
                  <a href="<?php echo e($footer_banner->url); ?>">
                    <img src="/storage/<?php echo e($footer_banner->bannerpath); ?>" class="img-responsive center-block" alt="">
                  </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script>
  $(document).ready(function(){
    $('#menu_<?php echo e($menu->id); ?>').addClass('menu_active');
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>