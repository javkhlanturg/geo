<?php $__env->startSection('css'); ?>
<style>
 .order{
   background:#fc7100; color:#fff; border:0px; padding:5px
 }
 .order:hover{
   padding:6px
 }
 .pagenation li span {
     display: block;
     color: #fff;
     font-size: 12px;
     font-weight: bold;
     padding: 4px 11px;
     background-color: #989898;
 }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section id="content" class="eight column row pull-left">
  <h4 class="cat-title mb25"><?php echo e($menu->title); ?></h4>

  <!-- Posts -->
  <section class="row">
    <!-- Category posts -->
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <article class="post">
      <div class="post-container">
        <div class="post-content">
          <img src="/<?php echo e($post->ifimage); ?>" alt="" style="height:130px;width:220px;object-fit: cover;float: left;margin-right:20px">
          <h2 class="post-title"><a href="#"><?php echo e($post->newstitle); ?></a></h2>
          <p><?php echo e($post->excerpt); ?></p>
          <div class="post-meta">
            <span class="date"><a href="#"><?php echo e(date('m сарын d, Y',strtotime($post->created_at))); ?></a></span>&nbsp;
            <span style="font-size:13px"> &nbsp; &nbsp;Үнэ: <?php echo e(number_format($post->price, 2)); ?>₮ &nbsp; &nbsp;</span>
            <button class="pull-right order"> Захиалах </button>
          </div>
        </div>
      </div>

    </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    <!-- End Category posts -->
  </section>
  <!-- End Posts -->

  <!-- Pagenation -->
  <?php if(isset($posts)): ?>
  <div class="pagenation clearfix">
    <?php echo e($posts->links()); ?>

  </div>
  <?php endif; ?>
  <!-- End Pagenation -->
</section>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('javascript'); ?>
  <script>
  $(document).ready(function(){
    var data = $('ul.pagination').removeClass().addClass("no-bullet");
  })
  </script>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>