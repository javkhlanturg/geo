<section class="row">
  <!-- Category posts -->
  <article class="six column">
    <h4 class="cat-title"><a href="#">Эдийн засаг</a></h4>
    <?php $__currentLoopData = $ediins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ed): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <?php if($loop->index === 0): ?>
    <div class="post-image">
      <a href="#"><img src="/<?php echo e($ed->image); ?>" alt=""></a>
    </div>

    <div class="post-container">
      <h2 class="post-title"><?php echo e($ed->title); ?></h2>
      <div class="post-content">
        <p><?php echo e($ed->excerpt); ?></p>
      </div>
    </div>

    <div class="post-meta">
      <span class="comments"><a href="#">24</a></span>
      <span class="author"><a href="#">Админ</a></span>
      <span class="date"><a href="#"><?php echo e(date('Y.m.d',strtotime($ed->created_at))); ?></a></span>
    </div>
    <?php else: ?>

    <div class="other-posts">
      <ul class="no-bullet">
        <li>
          <a href="#"><img src="/<?php echo e($ed->image); ?>-small" alt=""></a>
          <h3 class="post-title"><a href="#"><?php echo e($ed->title); ?></a></h3>
          <span class="date"><a href="#"><?php echo e(date('Y.m.d',strtotime($ed->created_at))); ?></a></span>
        </li>

      </ul>
    </div>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
  </article>
  <!-- End Category posts -->

  <!-- Category posts -->
  <article class="six column">
    <h4 class="cat-title"><a href="#">Технологи</a></h4>
    <?php $__currentLoopData = $tehnologys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tehnology): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <?php if($loop->index === 0): ?>
    <div class="post-image">
      <a href="#"><img src="/<?php echo e($tehnology->image); ?>" alt=""></a>
    </div>

    <div class="post-container">
      <h2 class="post-title"><?php echo e($tehnology->title); ?></h2>
      <div class="post-content">
        <p><?php echo e($tehnology->excerpt); ?></p>
      </div>
    </div>

    <div class="post-meta">
      <span class="comments"><a href="#">24</a></span>
      <span class="author"><a href="#">Админ</a></span>
      <span class="date"><a href="#"><?php echo e(date('Y.m.d',strtotime($tehnology->created_at))); ?></a></span>
    </div>
    <?php else: ?>

    <div class="other-posts">
      <ul class="no-bullet">
        <li>
          <a href="#"><img src="/<?php echo e($tehnology->image); ?>-small" alt=""></a>
          <h3 class="post-title"><a href="#"><?php echo e($tehnology->title); ?></a></h3>
          <span class="date"><a href="#"><?php echo e(date('Y.m.d',strtotime($tehnology->created_at))); ?></a></span>
        </li>

      </ul>
    </div>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
  </article>
  <!-- End Category posts -->
</section>
