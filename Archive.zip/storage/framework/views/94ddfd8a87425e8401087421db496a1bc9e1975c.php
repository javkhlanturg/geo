<?php $__env->startSection('content'); ?>
<section class="headding-news">
  <div class="container">
    <div class="row row-margin">

      <div class="col-sm-3 col-padding">
        <?php $i = 1; foreach($top_news as $top_new): ?>
          <?php if($i == 1): ?>
            <div class="post-wrapper post-grid-1 wow fadeIn" data-wow-duration="2s">
              <div class="post-thumb img-zoom-in">
                <a href="#">
                  <img class="entry-thumb" src="/storage/<?php echo e($top_new->image); ?>" alt="">
                </a>
              </div>
              <div class="post-info">
                <span class="color-3">Мэдээ </span>
                <h3 class="post-title post-title-size"><a href="/<?php echo e($top_new->category['slug']); ?>/<?php echo e($top_new->id); ?>" rel="bookmark"> <?php echo e($top_new->title); ?> </a></h3>
                <div class="post-editor-date">
                  <!-- post date -->
                  <div class="post-date">
                    <i class="pe-7s-clock"></i> <?php echo e(date('M d, Y', strtotime($top_new->created_at))); ?>

                  </div>
                  <!-- post comment -->
                  <div class="post-author-comment"><i class="pe-7s-comment"></i> <?php echo e($top_new->commentCount()); ?> </div>
                  <!-- read more -->
                  <a class="readmore pull-right" href="/<?php echo e($top_new->category['slug']); ?>/<?php echo e($top_new->id); ?>"><i class="pe-7s-angle-right"></i></a>
                </div>
              </div>
            </div>
          <?php elseif($i == 2):?>
            <div class="post-wrapper post-grid-2 wow fadeIn" data-wow-duration="2s">
              <div class="post-thumb img-zoom-in">
                <a href="#">
                  <img class="entry-thumb" src="/storage/<?php echo e($top_new->image); ?>" alt="">
                </a>
              </div>
              <div class="post-info">
                <span class="color-5">Мэдээ</span>
                <h3 class="post-title post-title-size"><a href="/<?php echo e($top_new->category['slug']); ?>/<?php echo e($top_new->id); ?>" rel="bookmark"><?php echo e($top_new->title); ?> </a></h3>
                <div class="post-editor-date">
                  <!-- post date -->
                  <div class="post-date">
                    <i class="pe-7s-clock"></i> <?php echo e(date('M d, Y', strtotime($top_new->created_at))); ?>

                  </div>
                  <!-- post comment -->
                  <div class="post-author-comment"><i class="pe-7s-comment"></i> <?php echo e($top_new->commentCount()); ?> </div>
                  <!-- read more -->
                  <a class="readmore pull-right" href="/<?php echo e($top_new->category['slug']); ?>/<?php echo e($top_new->id); ?>"><i class="pe-7s-angle-right"></i></a>
                </div>
              </div>
            </div>
          <?php endif; ?>
          <?php $i++; endforeach;?>
        </div>

        <div class="col-sm-6 col-padding">
          <?php $i = 1; foreach($top_news as $top_new): ?>
            <?php if($i == 3):?>
              <div class="post-wrapper post-grid-3 wow fadeIn" data-wow-duration="2s">
                <div class="post-thumb img-zoom-in">
                  <a href="#">
                    <img class="entry-thumb-middle" src="/storage/<?php echo e($top_new->image); ?>" alt="">
                  </a>
                </div>
                <div class="post-info">
                  <span class="color-4">Мэдээ</span>
                  <h3 class="post-title"><a href="/<?php echo e($top_new->category['slug']); ?>/<?php echo e($top_new->id); ?>" rel="bookmark"><?php echo e($top_new->title); ?> </a></h3>
                  <div class="post-editor-date">
                    <!-- post date -->
                    <div class="post-date">
                      <i class="pe-7s-clock"></i> <?php echo e(date('M d, Y', strtotime($top_new->created_at))); ?>

                    </div>
                    <!-- post comment -->
                    <div class="post-author-comment"><i class="pe-7s-comment"></i> <?php echo e($top_new->commentCount()); ?> </div>
                    <!-- read more -->
                    <a class="readmore pull-right" href="/<?php echo e($top_new->category['slug']); ?>/<?php echo e($top_new->id); ?>"><i class="pe-7s-angle-right"></i></a>
                  </div>
                </div>
              </div>
            <?php endif;?>
          <?php endforeach;?>
        </div>

        <div class="col-sm-3 col-padding">
          <?php $i = 1; foreach($top_news as $top_new): ?>
            <?php if($i == 4):?>

              <div class="post-wrapper post-grid-4 wow fadeIn" data-wow-duration="2s">
                <div class="post-thumb img-zoom-in">
                  <a href="#">
                    <img class="entry-thumb" src="\assets\images\slider\slide-09.jpg" alt="">
                  </a>
                </div>
                <div class="post-info">
                  <span class="color-1">Мэдээ</span>
                  <h3 class="post-title post-title-size"><a href="/<?php echo e($top_new->category['slug']); ?>/<?php echo e($top_new->id); ?>" rel="bookmark"><?php echo e($top_new->title); ?></a></h3>
                  <div class="post-editor-date">
                    <!-- post date -->
                    <div class="post-date">
                      <i class="pe-7s-clock"></i> <?php echo e(date('M d, Y', strtotime($top_new->created_at))); ?>

                    </div>
                    <!-- post comment -->
                    <div class="post-author-comment"><i class="pe-7s-comment"></i> <?php echo e($top_new->commentCount()); ?> </div>
                    <!-- read more -->
                    <a class="readmore pull-right" href="/<?php echo e($top_new->category['slug']); ?>/<?php echo e($top_new->id); ?>"><i class="pe-7s-angle-right"></i></a>
                  </div>
                </div>
              </div>
            <?php endif; ?>
          <?php endforeach;?>
          <?php $i = 1; foreach($top_news as $top_new): ?>
            <?php if($i == 5):?>
              <div class="post-wrapper post-grid-5 wow fadeIn" data-wow-duration="2s">
                <div class="post-thumb img-zoom-in">
                  <a href="#">
                    <img class="entry-thumb" src="\assets\images\slider\slide-10.jpg" alt="">
                  </a>
                </div>
                <div class="post-info">
                  <span class="color-2">Мэдээ</span>
                  <h3 class="post-title post-title-size"><a href="/<?php echo e($top_new->category['slug']); ?>/<?php echo e($top_new->id); ?>" rel="bookmark"><?php echo e($top_new->title); ?> </a></h3>
                  <div class="post-editor-date">
                    <!-- post date -->
                    <div class="post-date">
                      <i class="pe-7s-clock"></i> <?php echo e(date('M d, Y', strtotime($top_new->created_at))); ?>

                    </div>
                    <!-- post comment -->
                    <div class="post-author-comment"><i class="pe-7s-comment"></i> <?php echo e($top_new->commentCount()); ?> </div>
                    <!-- read more -->
                    <a class="readmore pull-right" href="/<?php echo e($top_new->category['slug']); ?>/<?php echo e($top_new->id); ?>"><i class="pe-7s-angle-right"></i></a>
                  </div>
                </div>
              </div>
            <?php endif; ?>
            <?php $i++; endforeach;?>
          </div>

        </div>
      </div>
    </section>
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-sm-8">


          <section class="recent_news_inner">
            <h3 class="category-headding ">Улс төр</h3>
            <div class="headding-border"></div>

            <div class="row rn_block">
              <?php $__currentLoopData = $uls_turs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tur): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <div class="col-md-4 col-sm-4 padd">
                <div class="home2-post">
                  <div class="post-wrapper wow fadeIn" data-wow-duration="1s">
                    <!-- image -->
                    <div class="img-thumb">
                      <a href="#">
                        <img class="entry-thumb" height="90" src="/storage/<?php echo e($tur->image); ?>" alt="">
                      </a>
                    </div>
                    <div class="post-info meta-info-rn">
                      <div class="slide">
                        <a target="_blank" href="#" class="post-badge btn_eight">У</a>
                      </div>
                    </div>
                  </div>
                  <div class="post-title-author-details">
                    <h4><a href="/<?php echo e($tur->category['slug']); ?>/<?php echo e($tur->id); ?>"><?php echo e($tur->title); ?></a></h4>
                    <div class="date">
                      <ul>
                        <li>By <a title="" href="#"><span>Админ</span></a> --</li>
                        <li><a title="" href="#"><?php echo e(date('M d, Y', strtotime($tur->created_at))); ?></a></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

            </div>
          </section>
          <section class="politics_wrapper">
            <h3 class="category-headding ">Эдийн засаг</h3>
            <div class="headding-border"></div>
            <div class="row rn_block">
              <?php $__currentLoopData = $zasags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zasag): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <div class="col-md-4 col-sm-4 padd">
                <div class="home2-post">
                  <div class="post-wrapper wow fadeIn" data-wow-duration="1s">
                    <!-- image -->
                    <div class="img-thumb">
                      <a href="#">
                        <img class="entry-thumb" height="90" src="/storage/<?php echo e($zasag->image); ?>" alt="">
                      </a>
                    </div>
                    <div class="post-info meta-info-rn">
                      <div class="slide">
                        <a target="_blank" href="#" class="post-badge btn_eight">У</a>
                      </div>
                    </div>
                  </div>
                  <div class="post-title-author-details">
                    <h4><a href="#"><?php echo e($zasag->title); ?></a></h4>
                    <div class="date">
                      <ul>
                        <li>By <a title="" href="#"><span>Админ</span></a> --</li>
                        <li><a title="" href="#"><?php echo e(date('M d, Y', strtotime($zasag->created_at))); ?></a></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

            </div>
          </section>
          <section class="politics_wrapper">
            <h3 class="category-headding ">Дэлхий</h3>
            <div class="headding-border"></div>
            <div class="row rn_block">
              <?php $__currentLoopData = $delhiis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $del): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <div class="col-md-4 col-sm-4 padd">
                <div class="home2-post">
                  <div class="post-wrapper wow fadeIn" data-wow-duration="1s">
                    <!-- image -->
                    <div class="img-thumb">
                      <a href="#">
                        <img class="entry-thumb" height="90" src="/storage/<?php echo e($del->image); ?>" alt="">
                      </a>
                    </div>
                    <div class="post-info meta-info-rn">
                      <div class="slide">
                        <a target="_blank" href="#" class="post-badge btn_eight">У</a>
                      </div>
                    </div>
                  </div>
                  <div class="post-title-author-details">
                    <h4><a href="#"><?php echo e($del->title); ?></a></h4>
                    <div class="date">
                      <ul>
                        <li>By <a title="" href="#"><span>Админ</span></a> --</li>
                        <li><a title="" href="#"><?php echo e(date('M d, Y', strtotime($del->created_at))); ?></a></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

            </div>
          </section>
          <!-- /.Politics -->
          <div class="ads">
            <a href="#"><img src="/storage/<?php echo e($footer_banner->bannerpath); ?>" class="img-responsive center-block" alt=""></a>
          </div>
          <section class="politics_wrapper">
            <h3 class="category-headding ">Видео</h3>
            <div class="headding-border"></div>
            <div class="row rn_block">
              <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <div class="col-md-4 col-sm-4 padd">
                <div class="home2-post">
                  <div class="post-wrapper wow fadeIn" data-wow-duration="1s">
                    <!-- image -->
                    <div class="post-thumb">

                      <a href="#" class="video-img-icon">
                        <i class="fa fa-play"></i>
                        <img class="img-responsive" src="\assets\images\recent_news_04.jpg" alt="">
                      </a>
                    </div>

                  </div>
                  <div class="post-title-author-details">
                    <h4><a href="#"><?php echo e($video->title); ?></a></h4>

                  </div>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

            </div>
          </section>
        </div>
        <!-- /.left content inner -->
        <?php echo $__env->make('frontend.rigthmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- side content end -->
      </div>
      <!-- row end -->
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>