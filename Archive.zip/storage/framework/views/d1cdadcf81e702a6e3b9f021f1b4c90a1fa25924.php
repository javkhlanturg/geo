<div class="flexslider mb25">
  <ul class="slides no-bullet inline-list m0">
    <?php $__currentLoopData = $top_newss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <li>
      <a href="#"><img alt="" src="/<?php echo e($news->image); ?>"></a>
      <div class="flex-caption">
        <div class="desc">
          <h1><a href="#"><?php echo e($news->title); ?></a></h1>
          <p><?php echo e($news->excerpt); ?></p>
          </div>
        </div>
      </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </ul>
      </div>
