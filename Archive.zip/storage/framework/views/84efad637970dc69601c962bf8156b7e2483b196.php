<?php $__env->startSection('content'); ?>
<div class="page-content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-bordered">
                  <?php if($news): ?>
                    <div class="panel-heading">
                        <h3 class="panel-title"><?php echo e($news->news->newstitle); ?></h3>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                          <div class="col-md-12">
                            <?php echo e($news->news->excerpt); ?>

                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-12">
                            <?php echo e($news->news->excerpt); ?>

                          </div>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="panel-body">
                        <div class="row">
                          <div class="col-md-12">
                          <p>Уучлаарай та мэдээ унших эрхгүй байна</p>
                        </div>
                      </div>
                  </div>
                    <?php endif; ?>
            </div>
        </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>