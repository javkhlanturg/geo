<?php $__env->startSection('css'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_header'); ?>
    <h1 class="page-title">
        <i class="<?php echo e($dataType->icon); ?>"></i> <?php echo e($dataType->display_name_singular); ?> <?php if(isset($dataTypeContent->id)): ?><?php echo e('засах'); ?><?php else: ?><?php echo e('шинэ'); ?><?php endif; ?>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content container-fluid">
        <div class="row">
            <div class="col-md-12">

                <div class="panel panel-bordered">

                    <div class="panel-heading">
                        <h3 class="panel-title"><?php echo e($dataType->display_name_singular); ?> <?php if(isset($dataTypeContent->id)): ?><?php echo e('засах'); ?><?php else: ?><?php echo e('Шинээр нэмэх'); ?><?php endif; ?> </h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form"
                          action="<?php if(isset($dataTypeContent->id)): ?><?php echo e(route('voyager.'.$dataType->slug.'.update', $dataTypeContent->id)); ?><?php else: ?><?php echo e(route('voyager.'.$dataType->slug.'.store')); ?><?php endif; ?>"
                          method="POST" enctype="multipart/form-data">
                        <!-- PUT Method if we are editing -->
                        <?php if(isset($dataTypeContent->id)): ?>
                            <?php echo e(method_field("PUT")); ?>

                        <?php endif; ?>

                        <!-- CSRF TOKEN -->
                        <?php echo e(csrf_field()); ?>


                        <div class="panel-body">

                            <?php if(count($errors) > 0): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                            <div class="form-group">
                                <label for="name">Гарчиг</label>
                                <input type="text" class="form-control" name="newstitle"
                                    placeholder="Энэ хэсэгт мэдээний гарчигаа оруулна уу" id="newstitle"
                                    value="<?php if(isset($dataTypeContent->newstitle)): ?><?php echo e(old('newstitle', $dataTypeContent->newstitle)); ?><?php else: ?><?php echo e(old('newstitle')); ?><?php endif; ?>">
                            </div>

                            <div class="form-group">
                                <label for="excerpt">Товч тайлбар</label>
                                <input type="text" class="form-control" name="excerpt"
                                       placeholder="Энэ хэсэгт мэдээний товч тайлбараа оруулна уу" id="excerpt"
                                       value="<?php if(isset($dataTypeContent->excerpt)): ?><?php echo e(old('excerpt', $dataTypeContent->excerpt)); ?><?php else: ?><?php echo e(old('excerpt')); ?><?php endif; ?>">
                            </div>
                            <div class="form-group">
                                <label for="price">Үнэ</label>
                                <input type="text" class="form-control" name="price"
                                       placeholder="Үнэ оруулна уу" id="price"
                                       value="<?php if(isset($dataTypeContent->price)): ?><?php echo e(old('price', $dataTypeContent->price)); ?><?php else: ?><?php echo e(old('price')); ?><?php endif; ?>">
                            </div>
                            <div class="form-group">
                                <label for="is_active">Мэдээний төлөв</label>
                                <select class="form-control" name="is_active">
                                    <option value="ACTIVE" <?php if(isset($dataTypeContent->is_active) && $dataTypeContent->is_active == 'ACTIVE'): ?><?php echo e('selected="selected"'); ?><?php endif; ?>>Идэвхитэй</option>
                                    <option value="INACTIVE" <?php if(isset($dataTypeContent->is_active) && $dataTypeContent->is_active == 'INACTIVE'): ?><?php echo e('selected="selected"'); ?><?php endif; ?>>Идэвхигүй</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="newfile">Цахим мэдээ</label>
                                <?php if(isset($dataTypeContent->newfile)): ?>
                                <div class="fileType"><?php echo e($dataTypeContent->newfile); ?></div>
                                <?php endif; ?>
                                <input type="file" name="newfile">
                            </div>

                            <div class="form-group">
                                <label for="ifimage">Зураг</label>
                                <?php if(isset($dataTypeContent->ifimage)): ?>
                                    <img src="<?php echo e(Voyager::image( $dataTypeContent->ifimage )); ?>"
                                         style="width:200px; height:auto; clear:both; display:block; padding:2px; border:1px solid #ddd; margin-bottom:10px;">
                                <?php endif; ?>
                                <input type="file" name="ifimage">
                            </div>



                        </div><!-- panel-body -->

                        <div class="panel-footer">
                            <button type="submit" class="btn btn-primary">Илгээх</button>
                        </div>
                    </form>

                    <iframe id="form_target" name="form_target" style="display:none"></iframe>
                    <form id="my_form" action="<?php echo e(route('voyager.upload')); ?>" target="form_target" method="post"
                          enctype="multipart/form-data" style="width:0;height:0;overflow:hidden">
                        <input name="image" id="upload_file" type="file"
                               onchange="$('#my_form').submit();this.value='';">
                        <input type="hidden" name="type_slug" id="type_slug" value="<?php echo e($dataType->slug); ?>">
                        <?php echo e(csrf_field()); ?>

                    </form>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        $('document').ready(function () {
            $('.toggleswitch').bootstrapToggle();
        });
    </script>
    <script src="<?php echo e(config('voyager.assets_path')); ?>/lib/js/tinymce/tinymce.min.js"></script>
    <script src="<?php echo e(config('voyager.assets_path')); ?>/js/voyager_tinymce.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>