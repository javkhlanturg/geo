<?php $__env->startSection('content'); ?>
<div class="page-content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-bordered">
                    <div class="panel-body">
                        <div id="dataTable_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                          <div class="row">
                              <table
                                id="dataTable"
                                class="table table-hover dataTable no-footer"
                                role="grid" aria-describedby="dataTable_info">
                                <thead>
                                  <tr role="row">
                                    <th >Д/д</th>
                                    <th >Сонингийн гарчиг</th>
                                    <th >Товч агуулга</th>
                                    <th > Төлөв </th>
                                    <th > Үнэ </th>
                                    <th > Нийтэлсэн </th>
                                  <th ></th></tr>
                            </thead>
                            <tbody>
                              <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <tr class="odd" role="row">
                                    <td> <?php echo e($loop->index+1); ?> </td>
                                    <td> <?php echo e($item->news->newstitle); ?> </td>
                                    <td> <?php echo e(str_limit($item->news->excerpt, 40)); ?> </td>
                                    <?php if( $item->status === 0 ): ?>
                                      <td> <span class="badge badge-info"> Захиалсан </span> </td>
                                    <?php elseif($item->status === 1): ?>
                                      <td> <span class="badge badge-success">Баталгаажсан</span> </td>
                                    <?php elseif($item->status === 2): ?>
                                      <td> <span class="badge badge-danger">Цуцалсан</span> </td>
                                    <?php endif; ?>
                                    <td> <?php echo e($item->news->newtitle); ?> </td>
                                    <td>  <?php echo e(number_format($item->news->price, 2)); ?> ₮ </td>
                                    <td>  <?php echo e(date('m сарын d, Y',strtotime($item->news->created_at))); ?> </td>
                                    <td>
                                      <?php if( $item->status === 0 ): ?>
                                      <a class="btn-sm btn-danger pull-center cancelorder" data-id="<?php echo e($item->id); ?>">
                                          Захиалга цуцлах
                                      </a>
                                      <?php elseif($item->status === 1): ?>
                                      <a class="btn-sm btn-info pull-center" href="/user/news/view/<?php echo e($item->news->id); ?>">
                                          Мэдээ унших
                                      </a>
                                      <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </tbody>
                        </table>
                      </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>

  <div class="modal modal-danger fade" tabindex="-1" id="cancel_modal" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h5 class="modal-title">
                        <i class="voyager-trash"></i> Захиалга цуцлах
                    </h5>
                </div>
                <div class="modal-body">
                  <p>Та захиалгыг цуцлахдаа итгэлтэй байна уу ?</p>
                </div>
                <div class="modal-footer">
                    <form action="<?php echo e(route('deleteOrder')); ?>" id="order_form" method="post">
                        <input type="hidden" name="orderid" id="orderid">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <input type="submit" class="btn btn-danger pull-right order-confirm" value="Тийм">
                    </form>
                    <button type="button" class="btn btn-default pull-right" data-dismiss="modal">Болих</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script>
$(document).ready(function(){
  $(document).on('click', '.cancelorder', function (e) {
      id = $(e.target).data('id');
      $('#orderid').val(id);
      $('#cancel_modal').modal('show');
  });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>