<?php $__env->startSection('page_header_actions'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-bordered">
                    <div class="panel-body">
                        <table id="dataTable" class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Захиалгын дугаар</th>
                                    <th>Захиалсан</th>
                                    <th>Мэдээ</th>
                                    <th>Төлөв</th>
                                    <th>Илгээсэн</th>
                                    <th class="actions">Үйлдлүүд</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $dataTypeContent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <tr>
                                    <td><?php echo e($data->id); ?></td>
                                    <td><?php echo e($data->user->email); ?></td>
                                    <td><?php echo e($data->news->newstitle); ?></td>
                                    <td><?php echo e($data->status); ?></td>
                                    <td><?php echo e($data->created_at); ?></td>
                                    <td class="no-sort no-click">
                                      <?php if($data->status === 0): ?>
                                        <div class="btn-sm btn-info pull-right acceptorder" data-id="<?php echo e($data->id); ?>">
                                            Батлах
                                        </div>
                                        <div class="btn-sm btn-danger pull-right cancelorder" data-id="<?php echo e($data->id); ?>">
                                            Цуцлах
                                        </div>
                                        <?php elseif($data->status === 1): ?>
                                        <span class="badge badge-success pull-right"> Баталгаажсан </span>
                                        <?php elseif($data->status === 2): ?>
                                        <span class="badge badge-danger pull-right"> Цуцалсан </span>
                                        <?php else: ?>
                                        <span><?php echo e($data->status); ?></span>
                                        <?php endif; ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal modal-danger fade" tabindex="-1" id="cancel_modal" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title"><i class="voyager-trash"></i> Захиалга цуцлах</h4>
                </div>
                <div class="modal-body">
                  <p>Та захиалгыг цуцлах гэж байна ?</p>
                </div>
                <div class="modal-footer">
                  <form id="cancel_form" role="form"
                        action="/admin/order"
                        method="POST">
                        <input name="_token" value="<?php echo e(csrf_token()); ?>" type="hidden">
                        <input name="_method" value="PUT" type="hidden">
                        <input name="status" value="2" type="hidden">
                        <input type="submit" class="btn btn-danger pull-right" value="Тийм">
                    </form>
                    <button type="button" class="btn btn-default pull-right" data-dismiss="modal">Болих</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->

    <div class="modal modal-info fade" tabindex="-1" id="accept_modal" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title"><i class="voyager-trash"></i> Захиалга баталгаажуулах</h4>
                </div>
                <div class="modal-body">
                  <p>Та захиалгыг баталгаажуулах гэж байна ?</p>
                </div>
                <div class="modal-footer">
                  <form id="accept_form" role="form"
                        action="/admin/order"
                        method="POST">
                        <input name="_token" value="<?php echo e(csrf_token()); ?>" type="hidden">
                        <input name="_method" value="PUT" type="hidden">
                        <input name="status" value="1" type="hidden">
                        <input type="submit" class="btn btn-info pull-right" value="Тийм">
                    </form>
                    <button type="button" class="btn btn-default pull-right" data-dismiss="modal">Болих</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <!-- DataTables -->
    <script>
        $(document).ready(function () {
            $('#dataTable').DataTable({ "order": [] });
        });

        $('td').on('click', '.acceptorder', function (e) {
            var form = $('#accept_form')[0];

            form.action = parseActionUrl(form.action, $(this).data('id'));

            $('#accept_modal').modal('show');
        });

        $('td').on('click', '.cancelorder', function (e) {
            var form = $('#cancel_form')[0];

            form.action = parseActionUrl(form.action, $(this).data('id'));

            $('#cancel_modal').modal('show');
        });

        function parseActionUrl(action, id) {
            return action.match(/\/[0-9]+$/)
                    ? action.replace(/([0-9]+$)/, id)
                    : action + '/' + id;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>