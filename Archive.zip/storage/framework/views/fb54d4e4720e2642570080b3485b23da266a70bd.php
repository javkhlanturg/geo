<?php $__env->startSection('content'); ?>
<section id="content" class="eight column row pull-left">
  <div class="page-container error-404">
    <p>error <b>404</b><span>Уучлаарай, хуудас олдсонгүй</span></p>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>