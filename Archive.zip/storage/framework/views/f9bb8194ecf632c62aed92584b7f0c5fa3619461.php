<?php $__env->startSection('content'); ?>
<div class="page-content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-bordered">
                    <div class="panel-body">
                        <div id="dataTable_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                          <div class="row">
                            <?php if(isset($list)): ?>
                            <?php echo e($list->links()); ?>

                            <?php endif; ?>
                              <table
                                id="dataTable"
                                class="table table-hover dataTable no-footer"
                                role="grid" aria-describedby="dataTable_info">
                                <thead>
                                  <tr role="row">
                                    <th >Д/д</th>
                                    <th >Сонингийн гарчиг</th>
                                    <th >Товч агуулга</th>
                                    <th > Үнэ </th>
                                    <th > Нийтэлсэн </th>
                                  <th ></th></tr>
                            </thead>
                            <tbody>
                              <?php $count = $list->firstItem();?>
                              <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <tr class="odd" role="row">
                                    <td> <?php echo e($count); ?> </td>
                                    <td> <?php echo e($item->newstitle); ?> </td>
                                    <td> <?php echo e(str_limit($item->excerpt, 40)); ?> </td>
                                    <td>  <?php echo e(number_format($item->price, 2)); ?> ₮ </td>
                                    <td>  <?php echo e(date('m сарын d, Y',strtotime($item->created_at))); ?> </td>
                                    <td>
                                      <a class="btn-sm btn-primary pull-right ordernews" data-id="<?php echo e($item->id); ?>">
                                          Захиалах
                                      </a>
                                    </td>
                                </tr>
                                <?php $count++;?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </tbody>
                        </table>
                        <?php if(isset($list)): ?>
                        <?php echo e($list->links()); ?>

                        <?php endif; ?>
                      </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>

  <div class="modal modal-info fade" tabindex="-1" id="order_modal" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h4 class="modal-title">
                        <i class="voyager-trash"></i> Сониг захиалах
                    </h4>
                </div>
                <div class="modal-body">
                  Та захиалга өгснөөр таны захиалсан сонгийн жагсаалтанд орох ба жагсаалт хэсгээс Захиалгын дугаарыг гүйлгээний утган дээр хийж явууна уу
                </div>
                <div class="modal-footer">
                    <form action="<?php echo e(route('orderNews')); ?>" id="order_form" method="post">
                        <input type="hidden" name="newsid" id="newsid">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <input type="submit" class="btn btn-info pull-right order-confirm" value="Сонинг захиална">
                    </form>
                    <button type="button" class="btn btn-default pull-right" data-dismiss="modal">Болих</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script>
$(document).ready(function(){
  $(document).on('click', '.ordernews', function (e) {
      id = $(e.target).data('id');
      $('#newsid').val(id);
      $('#order_modal').modal('show');
  });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>