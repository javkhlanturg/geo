<div class="clearfix mb10 oh">
  <h4 class="cat-title">Үйл явдал</h4>
  <!-- jCarousel -->
  <div class="carousel-container">
    <div class="carousel-navigation">
      <a class="carousel-prev"></a>
      <a class="carousel-next"></a>
    </div>
    <div class="carousel-item-holder row" data-index="0">
      <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
      <div class="four column carousel-item">
        <a href="#"><img src="/storage/<?php echo e($event->image); ?>" alt=""></a>

        <div class="post-container">
          <h2 class="post-title"><?php echo e($event->title); ?></h2>
          <div class="post-content">
            <p><?php echo e($event->excerpt); ?></p>
          </div>
        </div>

        <div class="post-meta">
          <span class="comments"><a href="#">24</a></span>
          <span class="date"><a href="#"><?php echo e(date('Y.m.d',strtotime($event->created_at))); ?></a></span>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </div>
  </div>
  <!-- End jCarousel -->
</div>
