<aside id="sidebar" class="four column pull-right">
   <?php $newss = \TCG\Voyager\Models\Post::limit('5')->get(); ?>
  <ul class="no-bullet">
    <li class="widget tabs-widget clearfix">
      <ul class="tab-links no-bullet clearfix">
        <li class="active"><a href="#popular-tab">Сүүлд нэмэгдсэн мэдээ</a></li>
      </ul>
      <div id="popular-tab">
        <ul>
          <?php $__currentLoopData = $newss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
          <li>
            <a href="#"><img alt="" src="/storage/<?php echo e($news->image); ?>"></a>
            <h3><a href="#"><?php echo e($news->title); ?></a></h3>
            <div class="post-date"><?php echo e(date('m сарын d, Y',strtotime($news->created_at))); ?></div>
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </ul>
      </div>
    </li>

    <li class="widget widget_ads_big clearfix">
      <?php $add_banner = App\Banners::where('id', 5)->first(); ?>
      <span class="add-title"></span>

      <h3 class="widget-title">- Сурталчилгаа -</h3>
      <div class="clearfix">
        <a href="<?php echo e($add_banner->url); ?>"><img src="/storage/<?php echo e($add_banner->bannerpath); ?>" alt=""></a>
      </div>
    </li>
    <li class="widget widget_facebook_box clearfix">
      <h3 class="widget-title">Find Us On Facebook</h3>
      <?php echo Voyager::setting('facebook_page'); ?>

    </li>
    <li class="widget widget_video clearfix">
      <h3 class="widget-title">Featured Video</h3>
      <div class="flex-video widescreen">
        <iframe src="http://www.youtube.com/embed/YdaMGcOyfjM" frameborder="0" webkitallowfullscreen="" mozallowfullscreen="" allowfullscreen=""></iframe>
      </div>
    </li>

  </ul>
</aside>
