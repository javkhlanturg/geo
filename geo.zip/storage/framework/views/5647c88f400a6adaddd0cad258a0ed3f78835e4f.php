<?php $__env->startSection('content'); ?>
<section id="content" class="eight column row pull-left">
  <h4 class="cat-title mb25"><?php echo e($menu->title); ?></h4>

  <!-- Posts -->
  <section class="row">
    <!-- Category posts -->
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <article class="post six column">
      <div class="post-image" style="object-fit: cover;">
        <a href="/<?php echo e($menu->url); ?>/<?php echo e($item->id); ?>"><img src="/storage/<?php echo e($item->image); ?>" alt="" style="height:130px;object-fit: cover;"></a>
      </div>

      <div class="post-container">
        <h2 class="post-title"><a href="<?php echo e($menu->url); ?>/<?php echo e($item->id); ?>"><?php echo e($item->title); ?></a></h2>
        <div class="post-content">
          <p><?php echo e($item->excerpt); ?></p>
        </div>
      </div>

      <div class="post-meta">
        <span class="comments"><a href="#"><?php echo e($item->commentCount()); ?></a></span>
        <span class="author"><a href="#"><?php echo e($item->user['name']); ?></a></span>
        <span class="date"><a href="#"><?php echo e(date('d.M.Y', strtotime($item->created_at))); ?></a></span>
      </div>
    </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

    <!-- End Category posts -->
  </section>
  <!-- End Posts -->

  <!-- Pagenation -->
  <div class="pagenation clearfix">
    <?php echo e($posts->links()); ?>

  </div>
  <!-- End Pagenation -->
</section>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>