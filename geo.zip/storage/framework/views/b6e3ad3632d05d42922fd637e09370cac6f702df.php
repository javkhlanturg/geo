<?php $__env->startSection('content'); ?>





    <section id="content" class="eight column row pull-left">

      <?php echo $__env->make('frontend.slide',['top_newss'=>$top_newss], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


      <?php echo $__env->make('frontend.busines',['business'=>$business,'uuls'=>$uuls], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


      <?php echo $__env->make('frontend.event',['events'=>$events], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <div class="ads-middle mb25">
        <a href="#"><img src="\assets\upload\468x60ads.jpg" alt=""></a>
      </div>


      <?php echo $__env->make('frontend.ediin',['ediins'=>$ediins,'tehnologys'=>$tehnologys], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


      <?php echo $__env->make('frontend.gallery', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;

    </section>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>