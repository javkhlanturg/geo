<?php $__env->startSection('content'); ?>
<section id="content" class="eight column row pull-left singlepost">
  <h4 class="post-title" style="text-align: center; color:#000">Хэрэглэгч бүртгүүлэх хэсэг</h4>
  <hr/>

  <div class="contact-form">
    <form action="<?php echo e(route('addRegister')); ?>" method="post">
      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
      <div id="register">
          <span>Хэрэглэгчийн нэр<input name="name" type="text" placeholder="Хэрэглэгчийн нэр"></span>
          <span>Мэйл хаяг<input name="email" type="text" placeholder="Мэйл хаяг"></span>
          <span>Нууц үг<input name="password" type="text" placeholder="Нууц үг"></span>
          <span>Утасны дугаар<input name="phone" type="text" placeholder="Утасны дугаар"></span>
      </div>
      <input type="submit" value="Бүртгүүлэх">
    </form>
    <div id="info" class="message"></div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>