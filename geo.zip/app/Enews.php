<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Enews extends Model
{
    protected $table = "enews";
    protected $primaryKey = "id";
}
