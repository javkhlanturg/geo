<footer class="row clearfix">
  				<!-- Footer widgets -->
  				<ul class="no-bullet clearfix">
  					<li class="widget four column">
  						<h3 class="widget-title">Холбоо барих</h3>
  			        	<div class="textwidget">
  			        		{!! Voyager::setting('contact_us') !!}
  			       		</div>
  					</li>
  					<li class="widget four column">
  						<h3 class="widget-title">Flicker Gallery</h3>
  	        			<div class="flickr-widget">
  	        				<ul class="block-grid four-up">
  	        						<li><a href="#"><img src="upload\thumb1.jpg" alt=""></a></li>
  	        						<li><a href="#"><img src="upload\thumb2.jpg" alt=""></a></li>
  	        						<li><a href="#"><img src="upload\thumb3.jpg" alt=""></a></li>
  	        						<li><a href="#"><img src="upload\thumb4.jpg" alt=""></a></li>
  	        						<li><a href="#"><img src="upload\thumb5.jpg" alt=""></a></li>
  	        						<li><a href="#"><img src="upload\thumb6.jpg" alt=""></a></li>
  	        						<li><a href="#"><img src="upload\thumb7.jpg" alt=""></a></li>
  	        						<li><a href="#"><img src="upload\thumb8.jpg" alt=""></a></li>
  	        						<li><a href="#"><img src="upload\thumb5.jpg" alt=""></a></li>
  	        						<li><a href="#"><img src="upload\thumb4.jpg" alt=""></a></li>
  	        						<li><a href="#"><img src="upload\thumb2.jpg" alt=""></a></li>
  	        						<li><a href="#"><img src="upload\thumb3.jpg" alt=""></a></li>
  	        				</ul>
  	        			</div>
  					</li>
  					<li class="widget four column">
  						<h3 class="widget-title">Twitter</h3>
  			        	<div class="twitter-widget">
  			        		<ul>
  			        			<li>
  			        				<p><a href="#">about 25 days ago</a> Lorem ipsum dolor sit amet nulla malesuda odio morbi nunc odio tristique: <br><a href="#">http://bit.ly/8b0wO4</a></p>
  			        			</li>
  			        			<li>
  			        				<p><a href="#">about 32 days ago</a> Malesuda orci ultricies pharetra onec accimsan curcus nec lorem aecenas: <br><a href="#">http://bit.ly/8b0wO4</a></p>
  			        			</li>
  			        			<li>
  			        				<p><a href="#">about 59 days ago</a> Socis vestibulum cing molestie malesuada odio onces accussam orci lorem: <br><a href="#">http://bit.ly/8b0wO4</a></p>
  			        			</li>
  			        		</ul>
  			        	</div>
  					</li>
  				</ul>
  				<!-- End Footer widgets -->

  				<div class="copyright clearfix">
  					© Copyright 2012 Pixelogic
  				</div>

  				<div id="back-to-top" class="right">
  					<a href="#top">Back to Top</a>
  				</div>
  			</footer>
